package com.example.przeksztalcenie;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private ImageView obrazek;
    private TextView info;
    private Bitmap orginal;
    private Random modi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        obrazek = findViewById(R.id.imageView);
        info = findViewById(R.id.textView);
        Button dodanie = findViewById(R.id.button);
        Button przeksztalc = findViewById(R.id.button2);

        modi = new Random();

        dodanie.setOnClickListener(v -> {
            orginal = BitmapFactory.decodeResource(getResources(), R.drawable.ratel);
            obrazek.setImageBitmap(orginal);

            if (orginal != null) {
                String inform = String.format("Szerokość %d px, Wysokość %d px", orginal.getWidth(), orginal.getHeight());
                info.setText(inform);
            } else {
                info.setText("Pobieranie obrazka nie powiodło się");
            }
        });

        przeksztalc.setOnClickListener(v -> {
            if (orginal != null) {
                Bitmap przeksztalcony = orginal.copy(Bitmap.Config.ARGB_8888, true);

                int szer = przeksztalcony.getWidth();
                int wys = przeksztalcony.getHeight();

                for (int x = 0; x < szer; x++) {
                    for (int y = 0; y < wys; y++) {

                        int dx = modi.nextInt(11) - 40;
                        int dy = modi.nextInt(11) - 40;

                        int newX = Math.max(0, Math.min(x + dx, szer - 1));
                        int newY = Math.max(0, Math.min(y + dy, wys - 1));


                        int pixel = orginal.getPixel(x, y);

                        przeksztalcony.setPixel(newX, newY, pixel);
                    }
                }
                obrazek.setImageBitmap(przeksztalcony);
            }
        });
    }
}
